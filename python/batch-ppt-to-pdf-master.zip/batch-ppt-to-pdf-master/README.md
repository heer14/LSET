# batch-ppt-to-pdf
Python script to convert a bunch of Microsoft Powerpoint files (.ppt or .pptx) to PDF. Powerpoint must be installed on the machine for this to work.

## Instructions for usage
1. Put this script in the same folder some powerpoint files
2. Run the script

```
python batch_ppt_to_pdf.py 
```
Tested with Python 3 on Windows
